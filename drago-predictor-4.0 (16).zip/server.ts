import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, get, set, update } from 'firebase/database';

const app = express();
const PORT = 3000;

app.use(express.json());

const firebaseConfig = {
  apiKey: "AIzaSyChOd_43HdYDs67AL3ZabIWUodddo6WsD4",
  authDomain: "saroj-boss-comming.firebaseapp.com",
  databaseURL: "https://saroj-boss-comming-default-rtdb.firebaseio.com",
  projectId: "saroj-boss-comming",
  storageBucket: "saroj-boss-comming.firebasestorage.app",
  messagingSenderId: "1091952246930",
  appId: "1:1091952246930:web:fd456d8b1fad2874f9a64b",
  measurementId: "G-PQX7D5CWTJ"
};

const firebaseApp = initializeApp(firebaseConfig);
const rtdb = getDatabase(firebaseApp);

const KEYS_FILE = path.join(process.cwd(), 'activated_keys.json');

const VALID_KEYS = [
  'DRAGO40',
  'TURBO40',
  'DRAGO-TURBO',
  'VIP-KEY',
  'ADMIN',
  'FREE-TRIAL',
  'RAMESH'
];

interface KeyRecord {
  key: string;
  deviceId: string;
  activatedAt: number;
  expiresAt: number;
}

// In-memory cache for cookies to minimize decryption overhead
let cachedCookie: string | null = null;
let cachedAesJs: string | null = null;

// Solver function to bypass InfinityFree slowAES protection
async function solveDragoChallenge(challengeHtml: string): Promise<string> {
  // If we don't have the aes.js content yet, download it once
  if (!cachedAesJs) {
    const aesRes = await fetch('https://dragoserverapi.infy.click/aes.js');
    cachedAesJs = await aesRes.text();
  }

  const aMatch = challengeHtml.match(/a=toNumbers\("([a-f0-9]+)"\)/);
  const bMatch = challengeHtml.match(/b=toNumbers\("([a-f0-9]+)"\)/);
  const cMatch = challengeHtml.match(/c=toNumbers\("([a-f0-9]+)"\)/);

  if (!aMatch || !bMatch || !cMatch) {
    throw new Error('Failed to parse challenge parameters (a, b, or c)');
  }

  const aHex = aMatch[1];
  const bHex = bMatch[1];
  const cHex = cMatch[1];

  const sandboxCode = `
    var i; // Avoid strict-mode issues inside the decryption loop
    ${cachedAesJs}
    function toNumbers(d){
      var e=[];
      d.replace(/(..)/g,function(d){e.push(parseInt(d,16))});
      return e;
    }
    function toHex(){
      for(var d=[],d=1==arguments.length&&arguments[0].constructor==Array?arguments[0]:arguments,e="",f=0;f<d.length;f++)
        e+=(16>d[f]?"0":"")+d[f].toString(16);
      return e.toLowerCase();
    }
    var a = toNumbers("${aHex}");
    var b = toNumbers("${bHex}");
    var c = toNumbers("${cHex}");
    var solved = toHex(slowAES.decrypt(c, 2, a, b));
    solved;
  `;

  // Safely evaluate to solve the cookie challenge
  const solvedCookie = eval(sandboxCode);
  return solvedCookie;
}

// Global helper to fetch with cookie bypass
async function fetchFromDrago(url: string, attempt = 0): Promise<any> {
  const headers: Record<string, string> = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  };

  if (cachedCookie) {
    headers['Cookie'] = `__test=${cachedCookie}`;
  }

  const response = await fetch(url, { headers });
  const responseText = await response.text();

  // If the server presents us with the slowAES page, we must solve it and re-request
  if (responseText.includes('slowAES.decrypt') && attempt < 3) {
    console.log(`[Proxy] Challenge detected for ${url}. Solving...`);
    const newCookie = await solveDragoChallenge(responseText);
    cachedCookie = newCookie;
    console.log(`[Proxy] New Cookie solved: ${newCookie}`);
    // Recurse with new cookie
    return fetchFromDrago(url, attempt + 1);
  }

  try {
    const parsed = JSON.parse(responseText);
    return parsed;
  } catch (err) {
    throw new Error(`Data format error or challenge solution outdated. Response text snippet: ${responseText.substring(0, 300)}`);
  }
}

// Define the API route for Drago live results
app.get('/api/drago-live-results', async (req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
  const mode = req.query.mode === '30sec' ? '30sec' : '1min';
  // Appended cache-breaker timestamp query parameters so target platform Cloudflare cache is bypassed
  const targetUrl = mode === '30sec' 
    ? `https://dragoserverapi.infy.click/wingo30s.php?_=${Date.now()}` 
    : `https://dragoserverapi.infy.click/daman.php?_=${Date.now()}`;

  try {
    const rawData = await fetchFromDrago(targetUrl);
    
    // Check if it has the standard nested structure data.list
    if (rawData && rawData.data && Array.isArray(rawData.data.list)) {
      const list = rawData.data.list;
      if (list.length > 0) {
        const latestPeriod = list[0].issueNumber;
        
        // Calculate the current active predicted period (latest completed + 1)
        let activePeriod = '';
        if (/^\d+$/.test(latestPeriod)) {
          try {
            activePeriod = String(BigInt(latestPeriod) + 1n);
          } catch (e) {
            activePeriod = String(parseInt(latestPeriod) + 1);
          }
        } else {
          activePeriod = String(parseInt(latestPeriod) + 1 || Date.now());
        }

        // Map the list history items to clean records
        const history = list.map((item: any, idx: number) => {
          const num = parseInt(item.number) || 0;
          let color = 'green';
          const rawColor = String(item.color || '').toLowerCase();
          if (rawColor.includes('violet')) {
            color = 'purple';
          } else if (rawColor.includes('red')) {
            color = 'red';
          } else if (rawColor.includes('green')) {
            color = 'green';
          }

          return {
            period: item.issueNumber,
            number: num,
            predictedNumber: num,
            color: color,
            result: num >= 5 ? 'BIG' : 'SMALL',
            accuracy: 95 + (parseInt(item.issueNumber.slice(-2)) || 0) % 5,
            timestamp: new Date(Date.now() - idx * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: 'WIN'
          };
        });

        // Send mapped clean payload to client
        const cleanPayload = {
          period: activePeriod,
          history: history
        };
        return res.json(cleanPayload);
      }
    }

    // Default fallback if structure is different
    res.json(rawData);
  } catch (err: any) {
    console.error(`[Proxy Error] Failed to load results for ${mode}:`, err.message);
    res.status(500).json({ error: true, message: err.message });
  }
});

// Key activation and device binding, matching DRAGO KEYFORGE schema (createdAt, expiresAt, used)
app.post('/api/activate-key', async (req, res) => {
  try {
    const { key, deviceId } = req.body;
    if (!key || !deviceId) {
      return res.status(400).json({ error: true, message: 'Opps! Please enter a key and device identifier.' });
    }

    const trimmedKey = String(key).trim().toUpperCase();
    const keyRef = ref(rtdb, 'keys/' + trimmedKey);
    const snapshot = await get(keyRef);

    if (!snapshot.exists()) {
      return res.status(400).json({ error: true, message: 'Opps! The key you entered is invalid or already used.' });
    }

    const record = snapshot.val();
    const createdAt = Number(record.createdAt ?? Date.now());
    const expiresAt = Number(record.expiresAt ?? 0);
    const used = !!record.used;
    const savedDeviceId = record.deviceId ?? '';

    // Key already expired (admin set absolute expiry, independent of activation time)
    if (Date.now() >= expiresAt) {
      return res.status(400).json({
        error: true,
        message: 'Your key has expired. Please buy or use a new key.'
      });
    }

    // Direct single-use check: If used, it cannot be activated again at all
    if (used) {
      return res.status(400).json({
        error: true,
        message: 'This key has already been activated/used. A key can only be used once!'
      });
    }

    // Compute total validity in days from admin's own createdAt/expiresAt span (for UI display)
    const totalDays = Math.max(1, Math.round((expiresAt - createdAt) / (24 * 60 * 60 * 1000)));

    // First time this key is being used: mark it used + bind device, WITHOUT wiping admin's fields
    if (!used) {
      await update(keyRef, {
        used: true,
        deviceId: deviceId,
        activatedAt: Date.now()
      });
    }

    return res.json({
      success: true,
      keyName: trimmedKey,
      days: totalDays,
      activatedAt: record.activatedAt ?? Date.now(),
      expiresAt: expiresAt
    });
  } catch (err: any) {
    console.error('[Firebase Activation Error]:', err);
    return res.status(500).json({ error: true, message: 'Firebase connection error: ' + err.message });
  }
});

// Periodic validation endpoint
app.get('/api/validate-key', async (req, res) => {
  try {
    const { key, deviceId } = req.query;
    if (!key || !deviceId) {
      return res.json({ valid: false, message: 'Missing parameters' });
    }

    const trimmedKey = String(key).trim().toUpperCase();
    const keyRef = ref(rtdb, 'keys/' + trimmedKey);
    const snapshot = await get(keyRef);

    if (!snapshot.exists()) {
      return res.json({ valid: false, message: 'Key not activated or invalid' });
    }

    const record = snapshot.val();
    const savedDeviceId = record.deviceId ?? '';
    const expiresAt = Number(record.expiresAt ?? 0);
    const createdAt = Number(record.createdAt ?? Date.now());
    const days = Math.max(1, Math.round((expiresAt - createdAt) / (24 * 60 * 60 * 1000)));

    if (savedDeviceId && savedDeviceId !== deviceId) {
      return res.json({ 
        valid: false, 
        message: 'This key is already used on another device. Key single-use constraint violated!' 
      });
    }

    if (Date.now() >= expiresAt) {
      return res.json({ 
        valid: false, 
        message: `Your key has expired. Please get a new key!` 
      });
    }

    return res.json({
      valid: true,
      expiresAt: expiresAt,
      days: days,
      remainingMs: expiresAt - Date.now()
    });
  } catch (err: any) {
    console.error('[Firebase Validation Error]:', err);
    return res.json({ valid: false, message: 'Firebase connection error: ' + err.message });
  }
});

// Serve health status
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', proxyAlive: true });
});

// Vite middleware configuration for development vs. production static paths
async function setupVite() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server fully running on http://0.0.0.0:${PORT}`);
  });
}

setupVite();
